# StorePOS Terminal Launcher v1.1.0 — White Edition

This release redesigns StorePOS Terminal Launcher around a clean white tablet interface with blue/teal StorePOS branding.

## Highlights

- White-first StorePOS launcher UI with a new blue/teal shopping-bag + receipt mark.
- Large **Open Register** action and dedicated **Device Settings** action.
- Responsive tablet/portrait layouts with touch animations and status cards.
- StorePOS installation and version detection for `com.storepos.app`.
- StorePOS update warning with release-channel check.
- Restricted terminal settings for Wi-Fi, Bluetooth/printer, brightness, volume, date/time, device information, and updates.
- Administrator PIN required for full Android Settings and exiting kiosk mode.
- Hidden administrator entry by long-pressing the StorePOS logo.
- Android Device Owner + Lock Task support with optional hiding of Play Store and common browsers.
- Persistent Home assignment for properly provisioned dedicated devices.
- Boot-to-launcher and optional auto-open StorePOS behavior.
- SUNMI device detection; receipt printing remains handled by StorePOS itself.
- Admin PIN upgraded to salted PBKDF2-HMAC-SHA256 storage with migration support from launcher-v1.0.0.

## Device Owner provisioning

On a freshly reset dedicated device:

```bash
adb shell dpm set-device-owner com.storepos.launcher/.admin.StorePosDeviceAdminReceiver
```

Then long-press the StorePOS logo, enter the administrator PIN, and enable **Kiosk lock**.
