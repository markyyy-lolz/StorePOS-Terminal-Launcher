package com.storepos.launcher

import android.content.Context
import android.provider.Settings
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class LauncherPrefs(private val context: Context) {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun hasAdminPin(): Boolean =
        !prefs.getString(KEY_PIN_HASH_V2, null).isNullOrBlank() ||
            !prefs.getString(KEY_PIN_HASH_LEGACY, null).isNullOrBlank()

    fun setAdminPin(pin: String) {
        require(pin.length in 4..8 && pin.all(Char::isDigit)) { "PIN must contain 4–8 digits." }
        val salt = ByteArray(16).also(SecureRandom()::nextBytes)
        val hash = derive(pin, salt)
        prefs.edit()
            .putString(KEY_PIN_SALT_V2, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(KEY_PIN_HASH_V2, Base64.encodeToString(hash, Base64.NO_WRAP))
            .remove(KEY_PIN_HASH_LEGACY)
            .apply()
    }

    fun verifyAdminPin(pin: String): Boolean {
        val saltB64 = prefs.getString(KEY_PIN_SALT_V2, null)
        val hashB64 = prefs.getString(KEY_PIN_HASH_V2, null)
        if (!saltB64.isNullOrBlank() && !hashB64.isNullOrBlank()) {
            val salt = runCatching { Base64.decode(saltB64, Base64.NO_WRAP) }.getOrNull() ?: return false
            val expected = runCatching { Base64.decode(hashB64, Base64.NO_WRAP) }.getOrNull() ?: return false
            val actual = derive(pin, salt)
            return MessageDigest.isEqual(expected, actual)
        }

        // Migration path for the original launcher-v1.0.0 PIN format.
        val legacy = prefs.getString(KEY_PIN_HASH_LEGACY, null) ?: return false
        val ok = MessageDigest.isEqual(
            legacy.toByteArray(Charsets.UTF_8),
            legacyHash(pin).toByteArray(Charsets.UTF_8)
        )
        if (ok) setAdminPin(pin)
        return ok
    }

    var kioskEnabled: Boolean
        get() = prefs.getBoolean(KEY_KIOSK_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_KIOSK_ENABLED, value).apply()

    var autoOpenStorePos: Boolean
        get() = prefs.getBoolean(KEY_AUTO_OPEN_STOREPOS, false)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_OPEN_STOREPOS, value).apply()

    var bootToLauncher: Boolean
        get() = prefs.getBoolean(KEY_BOOT_TO_LAUNCHER, true)
        set(value) = prefs.edit().putBoolean(KEY_BOOT_TO_LAUNCHER, value).apply()

    var hideOtherAppsInKiosk: Boolean
        get() = prefs.getBoolean(KEY_HIDE_OTHER_APPS, true)
        set(value) = prefs.edit().putBoolean(KEY_HIDE_OTHER_APPS, value).apply()

    var brightness: Float
        get() = prefs.getFloat(KEY_BRIGHTNESS, 0.82f).coerceIn(0.05f, 1f)
        set(value) = prefs.edit().putFloat(KEY_BRIGHTNESS, value.coerceIn(0.05f, 1f)).apply()

    private fun derive(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, PBKDF2_ITERATIONS, 256)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                .generateSecret(spec)
                .encoded
        } finally {
            spec.clearPassword()
        }
    }

    private fun legacyHash(pin: String): String {
        val androidId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
            .orEmpty()
        val bytes = MessageDigest.getInstance("SHA-256")
            .digest("storepos-terminal:$androidId:$pin".toByteArray())
        return bytes.joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }

    companion object {
        private const val PREFS_NAME = "storepos_terminal_launcher"
        private const val KEY_PIN_SALT_V2 = "admin_pin_salt_v2"
        private const val KEY_PIN_HASH_V2 = "admin_pin_hash_v2"
        private const val KEY_PIN_HASH_LEGACY = "admin_pin_hash"
        private const val KEY_KIOSK_ENABLED = "kiosk_enabled"
        private const val KEY_AUTO_OPEN_STOREPOS = "auto_open_storepos"
        private const val KEY_BOOT_TO_LAUNCHER = "boot_to_launcher"
        private const val KEY_HIDE_OTHER_APPS = "hide_other_apps"
        private const val KEY_BRIGHTNESS = "brightness"
        private const val PBKDF2_ITERATIONS = 120_000
    }
}
