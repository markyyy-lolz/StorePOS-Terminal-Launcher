package com.storepos.launcher

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

object ReleaseChecker {
    suspend fun latestStorePosVersion(): String? = withContext(Dispatchers.IO) {
        runCatching {
            val connection = (URL(BuildConfig.STOREPOS_RELEASES_API).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 5_000
                readTimeout = 5_000
                setRequestProperty("Accept", "application/vnd.github+json")
                setRequestProperty("User-Agent", "StorePOS-Terminal-Launcher/${BuildConfig.VERSION_NAME}")
            }

            try {
                if (connection.responseCode !in 200..299) return@runCatching null
                val text = connection.inputStream.bufferedReader().use { it.readText() }
                val releases = JSONArray(text)
                for (index in 0 until releases.length()) {
                    val release = releases.optJSONObject(index) ?: continue
                    if (release.optBoolean("draft", false) || release.optBoolean("prerelease", false)) continue
                    val tag = release.optString("tag_name")
                    val name = release.optString("name")
                    val normalized = (tag + " " + name).lowercase()

                    // StorePOS-Android temporarily hosted launcher-v1.x releases. Ignore those
                    // when deciding whether the main POS app is outdated.
                    if (normalized.contains("launcher") || normalized.contains("terminal launcher")) continue
                    VersionUtils.normalizeTag(tag)?.let { return@runCatching it }
                }
                null
            } finally {
                connection.disconnect()
            }
        }.getOrNull()
    }
}
