package com.storepos.launcher

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

data class StorePosStatus(
    val installed: Boolean,
    val versionName: String? = null,
    val versionCode: Long? = null,
    val baselineOutdated: Boolean = false
) {
    fun displayVersion(): String = versionName?.let { "v$it" } ?: "Not installed"
}

object StorePosStatusReader {
    fun read(context: Context): StorePosStatus {
        return try {
            @Suppress("DEPRECATION")
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(
                    BuildConfig.STOREPOS_PACKAGE,
                    PackageManager.PackageInfoFlags.of(0)
                )
            } else {
                context.packageManager.getPackageInfo(BuildConfig.STOREPOS_PACKAGE, 0)
            }

            val code = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                info.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                info.versionCode.toLong()
            }

            StorePosStatus(
                installed = true,
                versionName = info.versionName,
                versionCode = code,
                baselineOutdated = code < BuildConfig.MIN_STOREPOS_VERSION_CODE
            )
        } catch (_: PackageManager.NameNotFoundException) {
            StorePosStatus(installed = false)
        }
    }
}
