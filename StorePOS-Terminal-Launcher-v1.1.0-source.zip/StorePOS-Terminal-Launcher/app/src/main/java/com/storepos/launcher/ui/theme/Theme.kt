package com.storepos.launcher.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView

val StorePosBlue = Color(0xFF1578FF)
val StorePosBlueDark = Color(0xFF095CC7)
val StorePosTeal = Color(0xFF00AFA3)
val StorePosMint = Color(0xFFE7FBF8)
val StorePosSky = Color(0xFFEAF4FF)
val StorePosInk = Color(0xFF0E1B2A)
val StorePosMuted = Color(0xFF657487)
val StorePosBorder = Color(0xFFDCE6F0)
val StorePosPage = Color(0xFFF7FAFC)

private val StorePosLight = lightColorScheme(
    primary = StorePosBlue,
    onPrimary = Color.White,
    primaryContainer = StorePosSky,
    onPrimaryContainer = Color(0xFF05396F),
    secondary = StorePosTeal,
    onSecondary = Color.White,
    secondaryContainer = StorePosMint,
    onSecondaryContainer = Color(0xFF00534D),
    tertiary = Color(0xFF18A77F),
    background = StorePosPage,
    onBackground = StorePosInk,
    surface = Color.White,
    onSurface = StorePosInk,
    surfaceVariant = Color(0xFFF2F6FA),
    onSurfaceVariant = StorePosMuted,
    outline = StorePosBorder,
    outlineVariant = Color(0xFFEAF0F5),
    error = Color(0xFFD92D20),
    onError = Color.White
)

@Composable
fun StorePosLauncherTheme(content: @Composable () -> Unit) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = Color.White.toArgb()
            window.navigationBarColor = Color.White.toArgb()
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility =
                android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
                    } else 0
        }
    }

    MaterialTheme(
        colorScheme = StorePosLight,
        typography = Typography(),
        content = content
    )
}
