package com.storepos.launcher

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.Brightness6
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.InstallMobile
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Password
import androidx.compose.material.icons.rounded.PointOfSale
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Storefront
import androidx.compose.material.icons.rounded.SystemUpdate
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.AlertDialog
import androidx.compose.foundation.BorderStroke
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.storepos.launcher.ui.theme.StorePosBlue
import com.storepos.launcher.ui.theme.StorePosBorder
import com.storepos.launcher.ui.theme.StorePosInk
import com.storepos.launcher.ui.theme.StorePosLauncherTheme
import com.storepos.launcher.ui.theme.StorePosMint
import com.storepos.launcher.ui.theme.StorePosMuted
import com.storepos.launcher.ui.theme.StorePosSky
import com.storepos.launcher.ui.theme.StorePosTeal
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var prefs: LauncherPrefs
    private var resumeGeneration by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = LauncherPrefs(this)
        applyWindowBrightness(this, prefs.brightness)

        if (prefs.kioskEnabled && KioskController.isDeviceOwner(this)) {
            KioskController.applyKiosk(this, enabled = true, hideOtherApps = prefs.hideOtherAppsInKiosk)
        }

        setContent {
            StorePosLauncherTheme {
                StorePosLauncherApp(resumeGeneration)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::prefs.isInitialized) {
            applyWindowBrightness(this, prefs.brightness)
            if (prefs.kioskEnabled && KioskController.isDeviceOwner(this)) {
                KioskController.applyKiosk(this, enabled = true, hideOtherApps = prefs.hideOtherAppsInKiosk)
            }
        }
        resumeGeneration++
    }
}

private enum class LauncherPage { Home, DeviceSettings }

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun StorePosLauncherApp(resumeGeneration: Int) {
    val context = LocalContext.current
    val activity = context as Activity
    val prefs = remember { LauncherPrefs(context) }
    val scope = rememberCoroutineScope()

    var page by remember { mutableStateOf(LauncherPage.Home) }
    var hasPin by remember { mutableStateOf(prefs.hasAdminPin()) }
    var showAdminPin by remember { mutableStateOf(false) }
    var showAdminPanel by remember { mutableStateOf(false) }
    var showChangePin by remember { mutableStateOf(false) }
    var pendingAdminAction by remember { mutableStateOf<(() -> Unit)?>(null) }

    var kioskEnabled by remember { mutableStateOf(prefs.kioskEnabled) }
    var autoOpen by remember { mutableStateOf(prefs.autoOpenStorePos) }
    var bootToLauncher by remember { mutableStateOf(prefs.bootToLauncher) }
    var hideOtherApps by remember { mutableStateOf(prefs.hideOtherAppsInKiosk) }
    var storePosStatus by remember { mutableStateOf(StorePosStatusReader.read(context)) }
    var latestStorePosVersion by remember { mutableStateOf<String?>(null) }
    var checkingUpdates by remember { mutableStateOf(false) }
    var online by remember { mutableStateOf(NetworkUtils.isOnline(context)) }

    val deviceOwner = KioskController.isDeviceOwner(context)
    val updateAvailable = storePosStatus.baselineOutdated ||
        VersionUtils.isNewer(latestStorePosVersion, storePosStatus.versionName)

    fun requestAdmin(action: (() -> Unit)? = null) {
        pendingAdminAction = action
        showAdminPin = true
    }

    fun refreshStatus() {
        storePosStatus = StorePosStatusReader.read(context)
        online = NetworkUtils.isOnline(context)
        scope.launch {
            checkingUpdates = true
            latestStorePosVersion = ReleaseChecker.latestStorePosVersion()
            checkingUpdates = false
        }
    }

    LaunchedEffect(resumeGeneration) {
        storePosStatus = StorePosStatusReader.read(context)
        online = NetworkUtils.isOnline(context)
        checkingUpdates = true
        latestStorePosVersion = ReleaseChecker.latestStorePosVersion()
        checkingUpdates = false
    }

    LaunchedEffect(Unit) {
        if (hasPin && autoOpen && storePosStatus.installed) {
            delay(450)
            KioskController.openStorePos(context)
        }
    }

    if (!hasPin) {
        PinSetupScreen(
            onSet = { pin ->
                prefs.setAdminPin(pin)
                hasPin = true
            }
        )
        return
    }

    Crossfade(targetState = page, label = "launcher-page") { currentPage ->
        when (currentPage) {
            LauncherPage.Home -> LauncherHome(
                storePosStatus = storePosStatus,
                latestStorePosVersion = latestStorePosVersion,
                updateAvailable = updateAvailable,
                checkingUpdates = checkingUpdates,
                kioskEnabled = kioskEnabled,
                deviceOwner = deviceOwner,
                online = online,
                onOpenStorePos = {
                    if (!KioskController.openStorePos(context)) {
                        Toast.makeText(context, "StorePOS is not installed on this terminal.", Toast.LENGTH_LONG).show()
                        refreshStatus()
                    }
                },
                onOpenSettings = { page = LauncherPage.DeviceSettings },
                onAdminLongPress = { requestAdmin(null) },
                onInstallOrUpdate = {
                    requestAdmin {
                        KioskController.temporarilyReleaseLockTask(activity)
                        openUrl(context, BuildConfig.STOREPOS_RELEASES_URL)
                    }
                }
            )

            LauncherPage.DeviceSettings -> DeviceSettingsScreen(
                storePosStatus = storePosStatus,
                latestStorePosVersion = latestStorePosVersion,
                updateAvailable = updateAvailable,
                checkingUpdates = checkingUpdates,
                kioskEnabled = kioskEnabled,
                deviceOwner = deviceOwner,
                online = online,
                prefs = prefs,
                onBack = { page = LauncherPage.Home },
                onRefresh = { refreshStatus() },
                onAdminRequired = { action -> requestAdmin(action) },
                onKioskExited = {
                    kioskEnabled = false
                    prefs.kioskEnabled = false
                }
            )
        }
    }

    if (showAdminPin) {
        PinVerifyDialog(
            onDismiss = {
                showAdminPin = false
                pendingAdminAction = null
            },
            onVerify = { pin ->
                if (prefs.verifyAdminPin(pin)) {
                    showAdminPin = false
                    val action = pendingAdminAction
                    pendingAdminAction = null
                    if (action != null) action() else showAdminPanel = true
                    true
                } else false
            }
        )
    }

    if (showAdminPanel) {
        AdminPanelDialog(
            deviceOwner = deviceOwner,
            kioskEnabled = kioskEnabled,
            autoOpen = autoOpen,
            bootToLauncher = bootToLauncher,
            hideOtherApps = hideOtherApps,
            onDismiss = { showAdminPanel = false },
            onSetDefaultLauncher = {
                KioskController.temporarilyReleaseLockTask(activity)
                KioskController.openHomeSettings(context)
            },
            onOpenAndroidSettings = {
                showAdminPanel = false
                KioskController.openSystemSettings(activity)
            },
            onKioskChanged = { enabled ->
                val applied = KioskController.applyKiosk(activity, enabled, hideOtherApps)
                if (applied) {
                    kioskEnabled = enabled
                    prefs.kioskEnabled = enabled
                } else {
                    Toast.makeText(
                        context,
                        "Android Device Owner is required for full kiosk lock.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            },
            onAutoOpenChanged = {
                autoOpen = it
                prefs.autoOpenStorePos = it
            },
            onBootToLauncherChanged = {
                bootToLauncher = it
                prefs.bootToLauncher = it
            },
            onHideOtherAppsChanged = {
                hideOtherApps = it
                prefs.hideOtherAppsInKiosk = it
                if (kioskEnabled && deviceOwner) {
                    KioskController.applyKiosk(activity, enabled = true, hideOtherApps = it)
                }
            },
            onChangePin = { showChangePin = true },
            onExitKiosk = {
                kioskEnabled = false
                prefs.kioskEnabled = false
                showAdminPanel = false
                KioskController.exitKiosk(activity, hideOtherApps)
            }
        )
    }

    if (showChangePin) {
        PinSetupDialog(
            title = "Change administrator PIN",
            onDismiss = { showChangePin = false },
            onSet = { pin ->
                prefs.setAdminPin(pin)
                showChangePin = false
                Toast.makeText(context, "Administrator PIN updated.", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LauncherHome(
    storePosStatus: StorePosStatus,
    latestStorePosVersion: String?,
    updateAvailable: Boolean,
    checkingUpdates: Boolean,
    kioskEnabled: Boolean,
    deviceOwner: Boolean,
    online: Boolean,
    onOpenStorePos: () -> Unit,
    onOpenSettings: () -> Unit,
    onAdminLongPress: () -> Unit,
    onInstallOrUpdate: () -> Unit
) {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(30_000)
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        val wide = maxWidth >= 780.dp
        val outerPadding = if (wide) 34.dp else 20.dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = outerPadding, vertical = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().widthIn(max = 1240.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                BrandLockup(onAdminLongPress = onAdminLongPress)
                if (wide) ClockBlock(now)
            }

            Spacer(Modifier.height(if (wide) 38.dp else 28.dp))

            if (wide) {
                Row(
                    modifier = Modifier.fillMaxWidth().widthIn(max = 1240.dp),
                    horizontalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    OpenRegisterCard(
                        modifier = Modifier.weight(1.55f),
                        storePosStatus = storePosStatus,
                        onClick = onOpenStorePos
                    )
                    DeviceSettingsCard(
                        modifier = Modifier.weight(0.8f),
                        onClick = onOpenSettings
                    )
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxWidth().widthIn(max = 680.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    OpenRegisterCard(
                        modifier = Modifier.fillMaxWidth(),
                        storePosStatus = storePosStatus,
                        onClick = onOpenStorePos
                    )
                    DeviceSettingsCard(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = onOpenSettings
                    )
                }
            }

            AnimatedVisibility(visible = !storePosStatus.installed || updateAvailable) {
                Column(
                    Modifier.fillMaxWidth().widthIn(max = 1240.dp).padding(top = 18.dp)
                ) {
                    UpdateWarningCard(
                        installed = storePosStatus.installed,
                        installedVersion = storePosStatus.versionName,
                        latestVersion = latestStorePosVersion,
                        checking = checkingUpdates,
                        onInstallOrUpdate = onInstallOrUpdate
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            StatusPanel(
                modifier = Modifier.fillMaxWidth().widthIn(max = 1240.dp),
                storePosStatus = storePosStatus,
                kioskEnabled = kioskEnabled,
                deviceOwner = deviceOwner,
                online = online,
                wide = wide
            )

            Spacer(Modifier.height(26.dp))
            Row(
                modifier = Modifier.fillMaxWidth().widthIn(max = 1240.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Dedicated retail terminal",
                    style = MaterialTheme.typography.bodySmall,
                    color = StorePosMuted
                )
                if (wide) {
                    Text(
                        "StorePOS Terminal · v${BuildConfig.VERSION_NAME}",
                        style = MaterialTheme.typography.labelMedium,
                        color = StorePosMuted
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BrandLockup(onAdminLongPress: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.combinedClickable(
            onClick = {},
            onLongClick = onAdminLongPress
        )
    ) {
        Surface(
            modifier = Modifier.size(62.dp),
            shape = RoundedCornerShape(19.dp),
            color = Color.White,
            shadowElevation = 5.dp,
            tonalElevation = 0.dp
        ) {
            Image(
                painter = painterResource(R.drawable.storepos_logo_mark),
                contentDescription = "StorePOS",
                modifier = Modifier.padding(7.dp),
                contentScale = ContentScale.Fit
            )
        }
        Spacer(Modifier.width(14.dp))
        Column {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    "Store",
                    fontSize = 27.sp,
                    fontWeight = FontWeight.Black,
                    color = StorePosInk
                )
                Text(
                    "POS",
                    fontSize = 27.sp,
                    fontWeight = FontWeight.Black,
                    color = StorePosTeal
                )
            }
            Text(
                "TERMINAL LAUNCHER",
                style = MaterialTheme.typography.labelMedium.copy(letterSpacing = 1.4.sp),
                fontWeight = FontWeight.Bold,
                color = StorePosTeal
            )
        }
    }
}

@Composable
private fun ClockBlock(now: Date) {
    val time = remember(now) { SimpleDateFormat("h:mm a", Locale.getDefault()).format(now) }
    val date = remember(now) { SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(now) }
    Column(horizontalAlignment = Alignment.End) {
        Text(time, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = StorePosInk)
        Text(date, style = MaterialTheme.typography.bodyMedium, color = StorePosMuted)
    }
}

@Composable
private fun OpenRegisterCard(
    modifier: Modifier,
    storePosStatus: StorePosStatus,
    onClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.985f else 1f,
        animationSpec = spring(stiffness = 550f),
        label = "register-card-scale"
    )
    val shape = RoundedCornerShape(34.dp)

    Box(
        modifier = modifier
            .heightIn(min = 270.dp)
            .graphicsLayer(scaleX = scale, scaleY = scale)
            .shadow(12.dp, shape, clip = false)
            .clip(shape)
            .background(Color.White)
            .border(1.dp, StorePosBorder, shape)
            .clickable(
                interactionSource = interaction,
                indication = null,
                enabled = storePosStatus.installed,
                onClick = onClick
            )
            .padding(28.dp)
    ) {
        Column(
            Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = StorePosSky
                ) {
                    Icon(
                        Icons.Rounded.PointOfSale,
                        contentDescription = null,
                        tint = StorePosBlue,
                        modifier = Modifier.padding(13.dp).size(36.dp)
                    )
                }
                StatusChip(
                    text = if (storePosStatus.installed) "READY" else "NOT INSTALLED",
                    active = storePosStatus.installed,
                    darkBackground = false
                )
            }

            Column {
                Text(
                    "StorePOS",
                    color = StorePosTeal,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    if (storePosStatus.installed) "Open Register" else "Install StorePOS first",
                    color = StorePosInk,
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Black
                )
                Spacer(Modifier.height(7.dp))
                Text(
                    if (storePosStatus.installed) {
                        "Start selling · ${storePosStatus.displayVersion()}"
                    } else {
                        "Main POS package: ${BuildConfig.STOREPOS_PACKAGE}"
                    },
                    color = StorePosMuted,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(18.dp))
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (storePosStatus.installed) StorePosBlue else Color(0xFFE8EEF5)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 17.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            if (storePosStatus.installed) "Open register" else "StorePOS required",
                            color = if (storePosStatus.installed) Color.White else StorePosMuted,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.width(7.dp))
                        Icon(
                            Icons.Rounded.ArrowForward,
                            null,
                            tint = if (storePosStatus.installed) Color.White else StorePosMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DeviceSettingsCard(
    modifier: Modifier,
    onClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.985f else 1f,
        animationSpec = spring(stiffness = 550f),
        label = "settings-card-scale"
    )
    val shape = RoundedCornerShape(34.dp)

    Surface(
        modifier = modifier
            .heightIn(min = 270.dp)
            .graphicsLayer(scaleX = scale, scaleY = scale)
            .shadow(6.dp, shape, clip = false)
            .clip(shape)
            .border(1.dp, StorePosBorder, shape)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick),
        color = Color.White,
        shape = shape
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(26.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Surface(shape = RoundedCornerShape(18.dp), color = StorePosSky) {
                Icon(
                    Icons.Rounded.Settings,
                    null,
                    tint = StorePosBlue,
                    modifier = Modifier.padding(13.dp).size(35.dp)
                )
            }
            Column {
                Text(
                    "Device Settings",
                    fontSize = 27.sp,
                    fontWeight = FontWeight.Black,
                    color = StorePosInk
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Wi-Fi, printer, display, volume, device info and updates",
                    color = StorePosMuted,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Open settings", color = StorePosBlue, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(6.dp))
                    Icon(Icons.Rounded.ChevronRight, null, tint = StorePosBlue, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

@Composable
private fun UpdateWarningCard(
    installed: Boolean,
    installedVersion: String?,
    latestVersion: String?,
    checking: Boolean,
    onInstallOrUpdate: () -> Unit
) {
    Surface(
        color = Color(0xFFFFFAEB),
        shape = RoundedCornerShape(22.dp),
        modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFFF6D58A), RoundedCornerShape(22.dp))
    ) {
        Row(
            modifier = Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Surface(shape = CircleShape, color = Color(0xFFFFF0C2)) {
                Icon(
                    if (installed) Icons.Rounded.SystemUpdate else Icons.Rounded.InstallMobile,
                    null,
                    tint = Color(0xFF9A6700),
                    modifier = Modifier.padding(10.dp).size(24.dp)
                )
            }
            Column(Modifier.weight(1f)) {
                Text(
                    if (installed) "StorePOS update recommended" else "StorePOS is missing",
                    fontWeight = FontWeight.Bold,
                    color = StorePosInk
                )
                Text(
                    when {
                        !installed -> "Install StorePOS before this terminal can open the register."
                        checking -> "Checking the StorePOS release channel…"
                        latestVersion != null -> "Installed ${installedVersion ?: "unknown"} · Latest $latestVersion"
                        else -> "This installed version is below the launcher's supported baseline."
                    },
                    color = StorePosMuted,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            FilledTonalButton(onClick = onInstallOrUpdate) {
                Icon(Icons.Rounded.Download, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(7.dp))
                Text(if (installed) "Update" else "Install")
            }
        }
    }
}

@Composable
private fun StatusPanel(
    modifier: Modifier,
    storePosStatus: StorePosStatus,
    kioskEnabled: Boolean,
    deviceOwner: Boolean,
    online: Boolean,
    wide: Boolean
) {
    Surface(
        modifier = modifier,
        color = Color.White,
        shape = RoundedCornerShape(26.dp),
        shadowElevation = 2.dp
    ) {
        if (wide) {
            Row(
                Modifier.padding(10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatusTile(
                    Modifier.weight(1f),
                    if (online) Icons.Rounded.Wifi else Icons.Rounded.WifiOff,
                    "Network",
                    if (online) "Online" else "Offline",
                    online
                )
                StatusTile(
                    Modifier.weight(1f),
                    if (kioskEnabled) Icons.Rounded.Lock else Icons.Rounded.LockOpen,
                    "Kiosk",
                    if (kioskEnabled) "Locked" else if (deviceOwner) "Ready" else "Standard",
                    kioskEnabled || deviceOwner
                )
                StatusTile(
                    Modifier.weight(1f),
                    Icons.Rounded.Storefront,
                    "StorePOS",
                    storePosStatus.displayVersion(),
                    storePosStatus.installed
                )
                StatusTile(
                    Modifier.weight(1f),
                    Icons.Rounded.Devices,
                    "Terminal",
                    terminalLabel(),
                    KioskController.isSunmi()
                )
            }
        } else {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusTile(Modifier.weight(1f), if (online) Icons.Rounded.Wifi else Icons.Rounded.WifiOff, "Network", if (online) "Online" else "Offline", online)
                    StatusTile(Modifier.weight(1f), if (kioskEnabled) Icons.Rounded.Lock else Icons.Rounded.LockOpen, "Kiosk", if (kioskEnabled) "Locked" else "Standard", kioskEnabled || deviceOwner)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusTile(Modifier.weight(1f), Icons.Rounded.Storefront, "StorePOS", storePosStatus.displayVersion(), storePosStatus.installed)
                    StatusTile(Modifier.weight(1f), Icons.Rounded.Devices, "Terminal", terminalLabel(), KioskController.isSunmi())
                }
            }
        }
    }
}

@Composable
private fun StatusTile(
    modifier: Modifier,
    icon: ImageVector,
    label: String,
    value: String,
    active: Boolean
) {
    Surface(
        modifier = modifier,
        color = if (active) StorePosSky.copy(alpha = 0.62f) else Color(0xFFF7F9FB),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(icon, null, tint = if (active) StorePosBlue else StorePosMuted, modifier = Modifier.size(21.dp))
            Column(Modifier.weight(1f)) {
                Text(label, style = MaterialTheme.typography.labelSmall, color = StorePosMuted)
                Text(value, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun DeviceSettingsScreen(
    storePosStatus: StorePosStatus,
    latestStorePosVersion: String?,
    updateAvailable: Boolean,
    checkingUpdates: Boolean,
    kioskEnabled: Boolean,
    deviceOwner: Boolean,
    online: Boolean,
    prefs: LauncherPrefs,
    onBack: () -> Unit,
    onRefresh: () -> Unit,
    onAdminRequired: ((() -> Unit)) -> Unit,
    onKioskExited: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as Activity
    val audio = remember { context.getSystemService(AudioManager::class.java) }
    val maxVolume = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var volume by remember { mutableStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }
    var brightness by remember { mutableStateOf(prefs.brightness) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp, vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().widthIn(max = 1080.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "Back") }
            Spacer(Modifier.width(6.dp))
            Column(Modifier.weight(1f)) {
                Text("Device Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                Text("Only terminal essentials are exposed here.", color = StorePosMuted)
            }
            StatusChip(
                text = if (kioskEnabled) "KIOSK ON" else if (deviceOwner) "OWNER READY" else "STANDARD",
                active = kioskEnabled || deviceOwner,
                darkBackground = false
            )
        }

        Spacer(Modifier.height(22.dp))

        SettingsSection(title = "Connectivity & peripherals") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SettingsActionCard(
                    modifier = Modifier.weight(1f),
                    icon = if (online) Icons.Rounded.Wifi else Icons.Rounded.WifiOff,
                    title = "Wi-Fi",
                    subtitle = if (online) "Internet connected" else "Connect to a network",
                    tint = StorePosBlue,
                    onClick = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            runCatching {
                                activity.startActivity(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
                            }.onFailure {
                                onAdminRequired {
                                    KioskController.temporarilyReleaseLockTask(activity)
                                    launchSetting(context, Settings.ACTION_WIFI_SETTINGS)
                                }
                            }
                        } else {
                            onAdminRequired {
                                KioskController.temporarilyReleaseLockTask(activity)
                                launchSetting(context, Settings.ACTION_WIFI_SETTINGS)
                            }
                        }
                    }
                )
                SettingsActionCard(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.Bluetooth,
                    title = "Bluetooth",
                    subtitle = "Pair a printer or scanner",
                    tint = StorePosTeal,
                    onClick = { onAdminRequired { KioskController.openBluetoothSettings(activity) } }
                )
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SettingsActionCard(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.Print,
                    title = "Receipt printer",
                    subtitle = "Printer setup stays inside StorePOS",
                    tint = Color(0xFF7A5AF8),
                    onClick = {
                        if (!KioskController.openStorePos(context, printerSettingsHint = true)) {
                            Toast.makeText(context, "Install StorePOS first.", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
                SettingsActionCard(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.CalendarMonth,
                    title = "Date & time",
                    subtitle = "Administrator access required",
                    tint = Color(0xFFE05A2A),
                    onClick = { onAdminRequired { KioskController.openDateTimeSettings(activity) } }
                )
            }
        }

        Spacer(Modifier.height(18.dp))

        SettingsSection(title = "Display & sound") {
            SliderSettingCard(
                icon = Icons.Rounded.Brightness6,
                title = "Launcher brightness",
                valueLabel = "${(brightness * 100).toInt()}%",
                value = brightness,
                valueRange = 0.05f..1f,
                onValueChange = {
                    brightness = it
                    prefs.brightness = it
                    applyWindowBrightness(activity, it)
                }
            )
            Spacer(Modifier.height(12.dp))
            SliderSettingCard(
                icon = Icons.Rounded.VolumeUp,
                title = "Media volume",
                valueLabel = "${((volume / maxVolume) * 100).toInt()}%",
                value = volume,
                valueRange = 0f..maxVolume.toFloat(),
                onValueChange = {
                    volume = it
                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, it.toInt(), 0)
                }
            )
        }

        Spacer(Modifier.height(18.dp))

        SettingsSection(title = "Updates") {
            Surface(color = Color.White, shape = RoundedCornerShape(22.dp), shadowElevation = 1.dp) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = RoundedCornerShape(14.dp), color = StorePosSky) {
                            Icon(Icons.Rounded.SystemUpdate, null, tint = StorePosBlue, modifier = Modifier.padding(10.dp).size(24.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("StorePOS Android", fontWeight = FontWeight.Bold)
                            Text(
                                when {
                                    !storePosStatus.installed -> "Not installed"
                                    updateAvailable && latestStorePosVersion != null -> "${storePosStatus.displayVersion()} · Update $latestStorePosVersion available"
                                    updateAvailable -> "${storePosStatus.displayVersion()} · Update recommended"
                                    else -> "${storePosStatus.displayVersion()} · Up to date"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = StorePosMuted
                            )
                        }
                        StatusChip(
                            text = when {
                                !storePosStatus.installed -> "MISSING"
                                updateAvailable -> "UPDATE"
                                else -> "READY"
                            },
                            active = storePosStatus.installed && !updateAvailable,
                            darkBackground = false
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FilledTonalButton(onClick = onRefresh) {
                            Icon(Icons.Rounded.CloudDone, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(7.dp))
                            Text(if (checkingUpdates) "Checking…" else "Check again")
                        }
                        OutlinedButton(
                            onClick = {
                                onAdminRequired {
                                    KioskController.temporarilyReleaseLockTask(activity)
                                    openUrl(context, BuildConfig.STOREPOS_RELEASES_URL)
                                }
                            }
                        ) {
                            Icon(Icons.Rounded.Download, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(7.dp))
                            Text("Install / update")
                        }
                    }
                    HorizontalDivider(color = StorePosBorder)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Info, null, tint = StorePosMuted, modifier = Modifier.size(19.dp))
                        Spacer(Modifier.width(9.dp))
                        Text(
                            "Launcher v${BuildConfig.VERSION_NAME} · standalone update channel",
                            style = MaterialTheme.typography.bodySmall,
                            color = StorePosMuted,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(
                            onClick = {
                                onAdminRequired {
                                    KioskController.temporarilyReleaseLockTask(activity)
                                    openUrl(context, BuildConfig.LAUNCHER_RELEASES_URL)
                                }
                            }
                        ) { Text("Releases") }
                    }
                }
            }
        }

        Spacer(Modifier.height(18.dp))

        SettingsSection(title = "Device information") {
            InfoCard(
                rows = listOf(
                    "Manufacturer" to Build.MANUFACTURER.ifBlank { "Unknown" },
                    "Model" to Build.MODEL.ifBlank { "Unknown" },
                    "Android" to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
                    "Terminal class" to if (KioskController.isSunmi()) "SUNMI-compatible Android POS" else "Standard Android terminal",
                    "Device Owner" to if (deviceOwner) "Provisioned" else "Not provisioned"
                )
            )
        }

        Spacer(Modifier.height(18.dp))

        SettingsSection(title = "Administrator") {
            Surface(color = Color.White, shape = RoundedCornerShape(22.dp), shadowElevation = 1.dp) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    AdminActionRow(
                        icon = Icons.Rounded.AdminPanelSettings,
                        title = "Full Android Settings",
                        subtitle = "Requires administrator PIN"
                    ) {
                        onAdminRequired { KioskController.openSystemSettings(activity) }
                    }
                    HorizontalDivider(color = StorePosBorder)
                    AdminActionRow(
                        icon = if (kioskEnabled) Icons.Rounded.LockOpen else Icons.Rounded.Security,
                        title = if (kioskEnabled) "Exit kiosk mode" else "Kiosk status",
                        subtitle = if (kioskEnabled) "Unlock the terminal and restore hidden apps" else "Full kiosk requires Android Device Owner"
                    ) {
                        if (kioskEnabled) {
                            onAdminRequired {
                                onKioskExited()
                                KioskController.exitKiosk(activity, prefs.hideOtherAppsInKiosk)
                            }
                        } else {
                            onAdminRequired { KioskController.openHomeSettings(context) }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(28.dp))
    }
}

@Composable
private fun SettingsSection(title: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().widthIn(max = 1080.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = StorePosMuted)
        Spacer(Modifier.height(9.dp))
        content()
    }
}

@Composable
private fun SettingsActionCard(
    modifier: Modifier,
    icon: ImageVector,
    title: String,
    subtitle: String,
    tint: Color,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = modifier.heightIn(min = 136.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, StorePosBorder)
    ) {
        Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Surface(shape = RoundedCornerShape(13.dp), color = tint.copy(alpha = 0.11f)) {
                Icon(icon, null, tint = tint, modifier = Modifier.padding(9.dp).size(24.dp))
            }
            Column {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = StorePosMuted, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun SliderSettingCard(
    icon: ImageVector,
    title: String,
    valueLabel: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    Surface(color = Color.White, shape = RoundedCornerShape(22.dp), shadowElevation = 1.dp) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(13.dp), color = StorePosSky) {
                Icon(icon, null, tint = StorePosBlue, modifier = Modifier.padding(10.dp).size(24.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(title, fontWeight = FontWeight.Bold)
                    Text(valueLabel, color = StorePosMuted, style = MaterialTheme.typography.labelMedium)
                }
                Slider(value = value, onValueChange = onValueChange, valueRange = valueRange)
            }
        }
    }
}

@Composable
private fun InfoCard(rows: List<Pair<String, String>>) {
    Surface(color = Color.White, shape = RoundedCornerShape(22.dp), shadowElevation = 1.dp) {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 8.dp)) {
            rows.forEachIndexed { index, row ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(row.first, color = StorePosMuted, style = MaterialTheme.typography.bodyMedium)
                    Text(row.second, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (index < rows.lastIndex) HorizontalDivider(color = StorePosBorder)
            }
        }
    }
}

@Composable
private fun AdminActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = StorePosBlue, modifier = Modifier.size(25.dp))
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = StorePosMuted)
        }
        Icon(Icons.Rounded.ChevronRight, null, tint = StorePosMuted)
    }
}

@Composable
private fun StatusChip(text: String, active: Boolean, darkBackground: Boolean) {
    val bg = when {
        darkBackground -> Color.White.copy(alpha = 0.16f)
        active -> StorePosMint
        else -> Color(0xFFF1F4F7)
    }
    val fg = when {
        darkBackground -> Color.White
        active -> Color(0xFF087A67)
        else -> StorePosMuted
    }
    Surface(color = bg, shape = RoundedCornerShape(100.dp)) {
        Row(
            Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Icon(
                if (active) Icons.Rounded.CheckCircle else Icons.Rounded.Info,
                null,
                tint = fg,
                modifier = Modifier.size(14.dp)
            )
            Text(text, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = fg)
        }
    }
}

@Composable
private fun AdminPanelDialog(
    deviceOwner: Boolean,
    kioskEnabled: Boolean,
    autoOpen: Boolean,
    bootToLauncher: Boolean,
    hideOtherApps: Boolean,
    onDismiss: () -> Unit,
    onSetDefaultLauncher: () -> Unit,
    onOpenAndroidSettings: () -> Unit,
    onKioskChanged: (Boolean) -> Unit,
    onAutoOpenChanged: (Boolean) -> Unit,
    onBootToLauncherChanged: (Boolean) -> Unit,
    onHideOtherAppsChanged: (Boolean) -> Unit,
    onChangePin: () -> Unit,
    onExitKiosk: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Surface(shape = RoundedCornerShape(16.dp), color = StorePosSky) {
                Icon(Icons.Rounded.Shield, null, tint = StorePosBlue, modifier = Modifier.padding(11.dp).size(28.dp))
            }
        },
        title = { Text("Administrator Access", fontWeight = FontWeight.Black) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(13.dp)
            ) {
                Surface(
                    color = if (deviceOwner) StorePosMint else Color(0xFFFFFAEB),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            if (deviceOwner) Icons.Rounded.Security else Icons.Rounded.WarningAmber,
                            null,
                            tint = if (deviceOwner) StorePosTeal else Color(0xFF9A6700),
                            modifier = Modifier.size(21.dp)
                        )
                        Spacer(Modifier.width(9.dp))
                        Column {
                            Text(
                                if (deviceOwner) "Android Device Owner active" else "Standard launcher mode",
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                if (deviceOwner) "Full Lock Task policies are available."
                                else "Provision Device Owner for Home/Recents/status-bar enforcement.",
                                style = MaterialTheme.typography.bodySmall,
                                color = StorePosMuted
                            )
                        }
                    }
                }

                AdminToggle(
                    title = "Kiosk lock",
                    subtitle = "Keep the device inside StorePOS-approved apps.",
                    checked = kioskEnabled,
                    enabled = deviceOwner,
                    onCheckedChange = onKioskChanged
                )
                AdminToggle(
                    title = "Hide Play Store & browsers",
                    subtitle = "Applied only while Device Owner kiosk is enabled.",
                    checked = hideOtherApps,
                    enabled = deviceOwner,
                    onCheckedChange = onHideOtherAppsChanged
                )
                AdminToggle(
                    title = "Auto-open StorePOS",
                    subtitle = "Launch the register after the terminal launcher starts.",
                    checked = autoOpen,
                    enabled = true,
                    onCheckedChange = onAutoOpenChanged
                )
                AdminToggle(
                    title = "Boot to launcher",
                    subtitle = "Start the terminal launcher after device boot when Android permits it.",
                    checked = bootToLauncher,
                    enabled = true,
                    onCheckedChange = onBootToLauncherChanged
                )

                HorizontalDivider(color = StorePosBorder)

                FilledTonalButton(onClick = onSetDefaultLauncher, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Home, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Set as default Home app")
                }
                FilledTonalButton(onClick = onOpenAndroidSettings, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.AdminPanelSettings, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Open full Android Settings")
                }
                OutlinedButton(onClick = onChangePin, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Password, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Change administrator PIN")
                }
                if (kioskEnabled) {
                    OutlinedButton(
                        onClick = onExitKiosk,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Icon(Icons.Rounded.LockOpen, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Exit kiosk mode")
                    }
                }

                if (!deviceOwner) {
                    HorizontalDivider(color = StorePosBorder)
                    Text("Device Owner provisioning", fontWeight = FontWeight.Bold)
                    Text(
                        "On a freshly reset device with USB debugging enabled, run:",
                        color = StorePosMuted,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Surface(color = Color(0xFFF5F7FA), shape = RoundedCornerShape(12.dp)) {
                        Text(
                            "adb shell dpm set-device-owner com.storepos.launcher/.admin.StorePosDeviceAdminReceiver",
                            modifier = Modifier.padding(12.dp),
                            style = MaterialTheme.typography.bodySmall,
                            color = StorePosInk
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } }
    )
}

@Composable
private fun AdminToggle(
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = StorePosMuted)
        }
        Spacer(Modifier.width(10.dp))
        Switch(checked = checked, onCheckedChange = onCheckedChange, enabled = enabled)
    }
}

@Composable
private fun PinSetupScreen(onSet: (String) -> Unit) {
    Box(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(22.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier.widthIn(max = 480.dp).fillMaxWidth(),
            shape = RoundedCornerShape(30.dp),
            color = Color.White,
            shadowElevation = 8.dp
        ) {
            Column(Modifier.padding(30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Image(
                    painter = painterResource(R.drawable.storepos_logo_mark),
                    contentDescription = null,
                    modifier = Modifier.size(92.dp)
                )
                Spacer(Modifier.height(10.dp))
                Text("Secure this terminal", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                Text(
                    "Create the administrator PIN used for kiosk controls and full Android access.",
                    color = StorePosMuted,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(20.dp))
                PinSetupFields(onSet)
            }
        }
    }
}

@Composable
private fun PinSetupDialog(title: String, onDismiss: () -> Unit, onSet: (String) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = { PinSetupFields(onSet) },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun PinSetupFields(onSet: (String) -> Unit) {
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    val valid = pin.length in 4..8 && pin.all(Char::isDigit) && pin == confirm

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(
            value = pin,
            onValueChange = { pin = it.filter(Char::isDigit).take(8) },
            label = { Text("Administrator PIN") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = confirm,
            onValueChange = { confirm = it.filter(Char::isDigit).take(8) },
            label = { Text("Confirm PIN") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Text("Use 4–8 digits.", style = MaterialTheme.typography.bodySmall, color = StorePosMuted)
        Button(onClick = { onSet(pin) }, enabled = valid, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Rounded.Lock, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(7.dp))
            Text("Save administrator PIN")
        }
    }
}

@Composable
private fun PinVerifyDialog(onDismiss: () -> Unit, onVerify: (String) -> Boolean) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Rounded.Security, null, tint = StorePosBlue) },
        title = { Text("Administrator PIN", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = pin,
                    onValueChange = {
                        pin = it.filter(Char::isDigit).take(8)
                        error = false
                    },
                    label = { Text("PIN") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true
                )
                if (error) Text("Incorrect administrator PIN.", color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            Button(
                onClick = { error = !onVerify(pin) },
                enabled = pin.length >= 4
            ) { Text("Unlock") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

private fun launchSetting(context: Context, action: String) {
    runCatching {
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }.onFailure {
        Toast.makeText(context, "This setting is not available on this device.", Toast.LENGTH_SHORT).show()
    }
}

private fun openUrl(context: Context, url: String) {
    runCatching {
        context.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }.onFailure {
        Toast.makeText(context, "No browser is available. Exit kiosk mode and try again.", Toast.LENGTH_LONG).show()
    }
}

private fun terminalLabel(): String {
    return if (KioskController.isSunmi()) {
        "SUNMI"
    } else {
        Build.MODEL.ifBlank { "Android" }
    }
}

private fun applyWindowBrightness(activity: Activity, value: Float) {
    val params = activity.window.attributes
    params.screenBrightness = value.coerceIn(0.05f, 1f)
    activity.window.attributes = params
}
