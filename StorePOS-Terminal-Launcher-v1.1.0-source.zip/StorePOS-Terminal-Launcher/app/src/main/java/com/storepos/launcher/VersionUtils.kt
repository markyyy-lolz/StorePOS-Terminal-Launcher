package com.storepos.launcher

object VersionUtils {
    private val versionRegex = Regex("(\\d+)(?:\\.(\\d+))?(?:\\.(\\d+))?(?:[-+].*)?")

    fun normalizeTag(tag: String): String? {
        val cleaned = tag.trim()
            .removePrefix("refs/tags/")
            .removePrefix("storepos-")
            .removePrefix("StorePOS-")
            .removePrefix("v")
            .removePrefix("V")
        val match = versionRegex.find(cleaned) ?: return null
        return listOf(
            match.groupValues.getOrNull(1).orEmpty().ifBlank { "0" },
            match.groupValues.getOrNull(2).orEmpty().ifBlank { "0" },
            match.groupValues.getOrNull(3).orEmpty().ifBlank { "0" }
        ).joinToString(".")
    }

    fun compare(left: String, right: String): Int {
        val a = normalizeTag(left)?.split('.')?.map { it.toIntOrNull() ?: 0 } ?: return 0
        val b = normalizeTag(right)?.split('.')?.map { it.toIntOrNull() ?: 0 } ?: return 0
        for (i in 0..2) {
            if (a[i] != b[i]) return a[i].compareTo(b[i])
        }
        return 0
    }

    fun isNewer(latest: String?, installed: String?): Boolean {
        if (latest.isNullOrBlank() || installed.isNullOrBlank()) return false
        return compare(latest, installed) > 0
    }
}
