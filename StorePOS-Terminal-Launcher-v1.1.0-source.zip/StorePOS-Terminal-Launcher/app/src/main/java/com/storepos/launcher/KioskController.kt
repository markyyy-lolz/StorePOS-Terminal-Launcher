package com.storepos.launcher

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.UserManager
import android.provider.Settings
import com.storepos.launcher.admin.StorePosDeviceAdminReceiver

object KioskController {
    private val optionalBlockedPackages = listOf(
        "com.android.vending",              // Google Play Store
        "com.android.chrome",              // Chrome
        "com.google.android.googlequicksearchbox",
        "com.microsoft.emmx",              // Microsoft Edge
        "com.sec.android.app.sbrowser",    // Samsung Internet
        "org.mozilla.firefox"              // Firefox
    )

    private val kioskRestrictions = listOf(
        UserManager.DISALLOW_SAFE_BOOT,
        UserManager.DISALLOW_ADD_USER,
        UserManager.DISALLOW_FACTORY_RESET,
        UserManager.DISALLOW_MOUNT_PHYSICAL_MEDIA
    )

    private fun dpm(context: Context): DevicePolicyManager =
        context.getSystemService(DevicePolicyManager::class.java)

    fun adminComponent(context: Context): ComponentName =
        ComponentName(context, StorePosDeviceAdminReceiver::class.java)

    fun isDeviceOwner(context: Context): Boolean =
        runCatching { dpm(context).isDeviceOwnerApp(context.packageName) }.getOrDefault(false)

    fun isSunmi(): Boolean =
        Build.MANUFACTURER.equals("SUNMI", ignoreCase = true) ||
            Build.BRAND.equals("SUNMI", ignoreCase = true)

    fun openStorePos(context: Context, printerSettingsHint: Boolean = false): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(BuildConfig.STOREPOS_PACKAGE)
            ?: return false
        if (printerSettingsHint) {
            intent.putExtra("storepos.destination", "printer_settings")
            intent.putExtra("open_printer_settings", true)
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        context.startActivity(intent)
        return true
    }

    fun openHomeSettings(context: Context) {
        context.startActivity(
            Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    fun openSystemSettings(activity: Activity) {
        temporarilyReleaseLockTask(activity)
        activity.startActivity(Intent(Settings.ACTION_SETTINGS))
    }

    fun openBluetoothSettings(activity: Activity) {
        temporarilyReleaseLockTask(activity)
        activity.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
    }

    fun openDateTimeSettings(activity: Activity) {
        temporarilyReleaseLockTask(activity)
        activity.startActivity(Intent(Settings.ACTION_DATE_SETTINGS))
    }

    fun applyKiosk(activity: Activity, enabled: Boolean, hideOtherApps: Boolean): Boolean {
        val manager = dpm(activity)
        if (!manager.isDeviceOwnerApp(activity.packageName)) return false
        val admin = adminComponent(activity)

        if (enabled) {
            val allowlisted = mutableListOf(activity.packageName)
            if (StorePosStatusReader.read(activity).installed) {
                allowlisted += BuildConfig.STOREPOS_PACKAGE
            }

            runCatching { manager.setLockTaskPackages(admin, allowlisted.distinct().toTypedArray()) }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                runCatching { manager.setLockTaskFeatures(admin, DevicePolicyManager.LOCK_TASK_FEATURE_NONE) }
            }

            runCatching { manager.setStatusBarDisabled(admin, true) }
            runCatching { manager.setKeyguardDisabled(admin, true) }
            kioskRestrictions.forEach { restriction ->
                runCatching { manager.addUserRestriction(admin, restriction) }
            }

            setPersistentHome(activity, manager, admin)
            setDistractionsHidden(activity, manager, admin, hideOtherApps)

            if (manager.isLockTaskPermitted(activity.packageName)) {
                runCatching { activity.startLockTask() }
            }
        } else {
            runCatching { activity.stopLockTask() }
            runCatching { manager.setStatusBarDisabled(admin, false) }
            runCatching { manager.setKeyguardDisabled(admin, false) }
            runCatching { manager.setLockTaskPackages(admin, emptyArray()) }
            kioskRestrictions.forEach { restriction ->
                runCatching { manager.clearUserRestriction(admin, restriction) }
            }
            setDistractionsHidden(activity, manager, admin, false)
            runCatching { manager.clearPackagePersistentPreferredActivities(admin, activity.packageName) }
        }
        return true
    }

    fun temporarilyReleaseLockTask(activity: Activity) {
        if (!isDeviceOwner(activity)) return
        val manager = dpm(activity)
        val admin = adminComponent(activity)
        runCatching { activity.stopLockTask() }
        runCatching { manager.setStatusBarDisabled(admin, false) }
        setDistractionsHidden(activity, manager, admin, false)
    }

    fun exitKiosk(activity: Activity, hideOtherApps: Boolean) {
        applyKiosk(activity, enabled = false, hideOtherApps = hideOtherApps)
        openHomeSettings(activity)
    }

    private fun setPersistentHome(
        context: Context,
        manager: DevicePolicyManager,
        admin: ComponentName
    ) {
        val filter = IntentFilter(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            addCategory(Intent.CATEGORY_DEFAULT)
        }
        val component = ComponentName(context, MainActivity::class.java)
        runCatching { manager.addPersistentPreferredActivity(admin, filter, component) }
    }

    private fun setDistractionsHidden(
        context: Context,
        manager: DevicePolicyManager,
        admin: ComponentName,
        hidden: Boolean
    ) {
        optionalBlockedPackages.forEach { packageName ->
            if (packageName == context.packageName || packageName == BuildConfig.STOREPOS_PACKAGE) return@forEach
            runCatching { manager.setApplicationHidden(admin, packageName, hidden) }
        }
    }
}
