package com.storepos.launcher

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VersionUtilsTest {
    @Test
    fun normalizesStorePosTags() {
        assertEquals("1.4.0", VersionUtils.normalizeTag("v1.4.0"))
        assertEquals("2.1.3", VersionUtils.normalizeTag("storepos-v2.1.3"))
        assertEquals("3.0.0", VersionUtils.normalizeTag("3"))
    }

    @Test
    fun comparesSemanticVersions() {
        assertTrue(VersionUtils.isNewer("1.5.0", "1.4.9"))
        assertTrue(VersionUtils.isNewer("2.0.0", "1.99.99"))
        assertFalse(VersionUtils.isNewer("1.4.0", "1.4.0"))
        assertFalse(VersionUtils.isNewer("1.3.9", "1.4.0"))
    }
}
