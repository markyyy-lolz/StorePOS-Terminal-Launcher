plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.storepos.launcher"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.storepos.launcher"
        minSdk = 26
        targetSdk = 36
        versionCode = 2
        versionName = "1.1.0"

        buildConfigField("String", "STOREPOS_PACKAGE", "\"com.storepos.app\"")
        buildConfigField("long", "MIN_STOREPOS_VERSION_CODE", "14L")
        buildConfigField(
            "String",
            "STOREPOS_RELEASES_API",
            "\"https://api.github.com/repos/markyyy-lolz/StorePOS-Android/releases?per_page=20\""
        )
        buildConfigField(
            "String",
            "STOREPOS_RELEASES_URL",
            "\"https://github.com/markyyy-lolz/StorePOS-Android/releases\""
        )
        buildConfigField(
            "String",
            "LAUNCHER_RELEASES_URL",
            "\"https://github.com/markyyy-lolz/StorePOS-Terminal-Launcher/releases\""
        )
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    testImplementation("junit:junit:4.13.2")

    implementation("androidx.activity:activity-compose:1.11.0")
    implementation("androidx.compose.ui:ui:1.11.4")
    implementation("androidx.compose.ui:ui-tooling-preview:1.11.4")
    implementation("androidx.compose.foundation:foundation:1.11.4")
    implementation("androidx.compose.material:material-icons-extended:1.7.8")
    implementation("androidx.compose.material3:material3:1.4.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")

    debugImplementation("androidx.compose.ui:ui-tooling:1.11.4")
}
